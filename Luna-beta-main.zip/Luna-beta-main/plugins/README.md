## `⏤͟͞ू⃪ 𝐋𝕌𝐍𝔸 𝐁𝕆𝐓 𑁯★ᰍ`

![LunaBot Banner](https://files.catbox.moe/if757e.jpg)

📂 Aquí están todos los **comandos de LunaBot**.  
Cada archivo `.js` en esta carpeta es un plugin ✨.

- 🛡️ Administración de grupos  
- ℹ️ Información y menús  
- 👑 Comandos del owner  
- 🛠️ Herramientas varias  

✨ Para crear un comando nuevo, solo agrega un archivo en esta carpeta.
